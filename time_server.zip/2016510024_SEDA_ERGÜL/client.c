#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <time.h>
#include <string.h>


int main(int argc, char **argv){
  if(argc != 2){
    printf("Usage: %s <port>\n", argv[0]);
    exit(0);
  }

  int port = atoi(argv[1]);
  printf("Port: %d\n", port);

  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  char response[30];
  char request[30];
  char request1[30];
  char request2[30];
  char flag[0];
  char flag1[1]="a";
  char r1[20]="Get_DATE";
  char r2[20]="%H:%M:%S";
  char r3[20]="%Y/%m/%d-%H:%M:%S";
  int result;
  int result1;
  int result2;
  int result3;
  struct sockaddr_in serverAddress;
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_addr.s_addr = INADDR_ANY;
  serverAddress.sin_port = htons(port);

  connect(sockfd, (struct sockaddr*)&serverAddress, sizeof(serverAddress));
  printf("[+]Connected to the server\n");
  
  printf("please enter request:\n");
  scanf("%s", request);
  result=strcmp(request,r1);// check the same request or not for Get_DATE
  if(result==0){FILE *dosya = fopen("time.txt", "r");

int maxTahminiSatirUzunlugu = 255;
char satir[maxTahminiSatirUzunlugu];
printf("please enter request continue:\n");
    scanf("%s", request2);

while(fgets(satir, maxTahminiSatirUzunlugu, dosya)) 
{
   
    
    
    char * parca;
    
    parca = strtok (satir,",");
	
    int parcaIndex = 0;
    time_t lt; 
	lt=time(NULL); 
  struct tm* local=localtime(&lt); 
    
    
  
    
  // check the same request or not for other parameters.
    // ı read txt files.the file contains the appropriate
	
	while (parca != NULL)
	{
		parcaIndex++;
			
		//printf("parca: %s\n", parca);
		parca = strtok(NULL, ",");
		if((result3=strcmp(request2,parca))==0)
		{
		  if(parca =="%x"){
		   printf("Time is: %d",local->tm_hour);
		  recv(sockfd, response, 29, 0);
		printf("Time from server: %s", response);}
		else{recv(sockfd, response, 29, 0);
		printf("Time from server: %s", response);}
		
		return 0;
		
		}
		else if((result1=strcmp(request2,r2))==0)
		{
		 
		    printf("Time is: %d",local->tm_hour);
		    printf(": %d",local->tm_min); 
		    printf(":%d\n",local->tm_sec); 
		recv(sockfd, response, 29, 0);
		send(sockfd , flag1 , strlen(flag1) , 0);
		printf("Time from server: %s", response);
		return 0;
		}
		else if((result2=strcmp(request2,r3))==0)
		{
		printf("%d",local->tm_year);
		    printf("/ %d",local->tm_mon);
		    printf("/%d\n",local->tm_mday);
		    printf("Time is: %d",local->tm_hour);
		    printf(": %d",local->tm_min); 
		    printf(":%d\n",local->tm_sec); 
		recv(sockfd, response, 29, 0);
		send(sockfd , flag1 , strlen(flag1) , 0);
		printf("Time from server: %s", response);
		return 0;
		}
		
		
		
	}

 
}fclose(dosya);




 
  }
  
  else{
  send(sockfd , flag , strlen(flag) , 0); 
  printf("incorrect request");
  
  }
  
  return 0;

}
