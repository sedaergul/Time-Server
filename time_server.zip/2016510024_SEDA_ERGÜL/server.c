#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <time.h>
#include<string.h>	//strlen
#include<arpa/inet.h>	//inet_addr


#define BACKLOG 1000

int main(int argc, char **argv){
  if(argc != 2){
    printf("Usage: %s <port>\n", argv[0]);
    exit(0);
  }

  int port = atoi(argv[1]);
  printf("Port: %d\n", port);

  int n_client = 0;
  char client_message[5000];
  int read_size;
  int client_socket;
  int sockfd = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in serverAddress;
  serverAddress.sin_family = AF_INET;
  serverAddress.sin_addr.s_addr = INADDR_ANY;
  serverAddress.sin_port = htons(port);

  if(bind(sockfd, (struct sockaddr*)&serverAddress, sizeof(serverAddress))<0)
  {
  		perror("bind failed. Error");
		return 1;
  }
  puts("[+]Bind\n");

  listen(sockfd, BACKLOG);
  printf("[+]Listening for the client\n");

  int i = 1;
      
 

	
  while(i = 1){
  
client_socket = accept(sockfd, NULL, NULL);
     
    n_client++;
	 time_t lt; 
    lt=time(NULL); 
    struct tm* local=localtime(&lt); 
    printf("Time is: %d\n",local->tm_hour);
    printf("Minute: %d\n",local->tm_min); 
    printf("Second:%d\n",local->tm_sec); 
    time_t currentTime;
    struct tm* local1;
    time(&currentTime);
  local1=localtime(&currentTime);
	  send(client_socket, asctime(local1),30,0);
       printf("Client %d requested for time at %s", n_client, asctime(local1));
       
       
       puts(client_message);
       read_size=strlen(client_message);
       if(read_size!=0){
       printf("Incorrect Request");}
 
        
      
        
   
    
  }

  return 0;

}
